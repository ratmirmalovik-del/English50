import express from "express";
import session from "express-session";
import SQLiteStoreFactory from "connect-sqlite3";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import Stripe from "stripe";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import dotenv from "dotenv";
import path from "node:path";
import { mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
// Render terminates HTTPS at its proxy; trust the proxy so secure session cookies work.
app.set("trust proxy", 1);
const dbFile = path.resolve(process.env.DB_FILE || "./english50.sqlite");
mkdirSync(path.dirname(dbFile), { recursive: true });
if (process.env.NODE_ENV === "production" && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("SESSION_SECRET must be set to a random value of at least 32 characters in production.");
}
const db = new Database(dbFile);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 paid INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS progress(
 user_id INTEGER NOT NULL,
 lesson_id INTEGER NOT NULL,
 completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id, lesson_id),
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 stripe_session_id TEXT UNIQUE,
 amount_total INTEGER,
 currency TEXT,
 status TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const StripeStore = SQLiteStoreFactory(session);
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const port = Number(process.env.PORT || 3000);
const appUrl = process.env.APP_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${port}`;
const adminEmail = (process.env.ADMIN_EMAIL || "").toLowerCase();

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
// Stripe webhook requires the raw request body; keep this route before express.json().
app.post("/api/stripe-webhook", express.raw({type:"application/json"}), async (req,res)=>{
  if(!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.sendStatus(503);
  let event;
  try { event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET); }
  catch(err) { return res.status(400).send(`Webhook Error: ${err.message}`); }
  if(event.type === "checkout.session.completed"){
    const checkout = event.data.object;
    const userId = Number(checkout.metadata?.userId);
    if(userId && checkout.payment_status === "paid"){
      db.prepare("UPDATE users SET paid=1 WHERE id=?").run(userId);
      db.prepare("INSERT OR IGNORE INTO payments(user_id,stripe_session_id,amount_total,currency,status) VALUES(?,?,?,?,?)")
        .run(userId,checkout.id,checkout.amount_total,checkout.currency,"paid");
    }
  }
  res.json({received:true});
});
app.use(express.json({limit:"30kb"}));
app.use(session({
  store: new StripeStore({db: "sessions.sqlite", dir: path.dirname(dbFile)}),
  secret: process.env.SESSION_SECRET || "local-development-only-secret-change-me",
  resave: false, saveUninitialized: false,
  cookie: {httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:7*24*60*60*1000}
}));
const authLimiter = rateLimit({windowMs:15*60*1000, limit:20, standardHeaders:true, legacyHeaders:false});
const getUser = id => db.prepare("SELECT id,email,paid,created_at FROM users WHERE id=?").get(id);
const getProgress = id => db.prepare("SELECT lesson_id FROM progress WHERE user_id=? ORDER BY lesson_id").all(id).map(x=>x.lesson_id);
function requireAuth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"Потрібно увійти в акаунт."}); req.user=getUser(req.session.userId); if(!req.user)return res.status(401).json({error:"Акаунт не знайдено."}); next(); }

app.post("/api/auth/register",authLimiter,async(req,res)=>{
 const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"Вкажи коректну електронну пошту."});
 if(password.length<8 || password.length>100) return res.status(400).json({error:"Пароль має містити від 8 до 100 символів."});
 if(db.prepare("SELECT id FROM users WHERE email=?").get(email)) return res.status(409).json({error:"Ця пошта вже зареєстрована. Спробуй увійти."});
 const hash=await bcrypt.hash(password,12);
 const result=db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(email,hash);
 req.session.userId=Number(result.lastInsertRowid);
 res.status(201).json({user:getUser(req.session.userId),progress:[]});
});
app.post("/api/auth/login",authLimiter,async(req,res)=>{
 const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
 const row=db.prepare("SELECT * FROM users WHERE email=?").get(email);
 if(!row || !(await bcrypt.compare(password,row.password_hash))) return res.status(401).json({error:"Неправильна пошта або пароль."});
 req.session.userId=row.id;
 res.json({user:getUser(row.id),progress:getProgress(row.id)});
});
app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>{
 if(!req.session.userId)return res.json({user:null,progress:[]});
 const user=getUser(req.session.userId);res.json({user,progress:user?getProgress(user.id):[]});
});
app.get("/api/progress",requireAuth,(req,res)=>res.json({completed:getProgress(req.user.id)}));
app.post("/api/progress",requireAuth,(req,res)=>{
 if(!req.user.paid)return res.status(403).json({error:"Повний доступ відкривається після оплати."});
 const ids=Array.isArray(req.body.completed)?req.body.completed:[];
 if(ids.length>50 || ids.some(x=>!Number.isInteger(x)||x<0||x>49))return res.status(400).json({error:"Некоректні дані прогресу."});
 const existing=getProgress(req.user.id);
 const allowedNext=existing.length ? Math.max(...existing)+1 : 0;
 if(ids.some(id=>!existing.includes(id) && id!==allowedNext))
   return res.status(409).json({error:"Уроки потрібно проходити послідовно."});
 const insert=db.prepare("INSERT OR IGNORE INTO progress(user_id,lesson_id) VALUES(?,?)");
 const tx=db.transaction(()=>ids.forEach(id=>insert.run(req.user.id,id)));tx();
 res.json({completed:getProgress(req.user.id)});
});
app.post("/api/checkout",requireAuth,async(req,res)=>{
 if(req.user.paid)return res.status(409).json({error:"Повний доступ уже активний."});
 if(!stripe || !process.env.STRIPE_PRICE_ID)return res.status(503).json({error:"Оплата ще не налаштована адміністратором. Додайте ключі Stripe у змінні середовища."});
 try{
  const checkout=await stripe.checkout.sessions.create({
   mode:"payment",payment_method_types:["card"],
   line_items:[{price:process.env.STRIPE_PRICE_ID,quantity:1}],
   success_url:`${appUrl}/?payment=success`,cancel_url:`${appUrl}/?payment=cancelled`,
   customer_email:req.user.email,metadata:{userId:String(req.user.id)}
  });
  res.json({url:checkout.url});
 }catch(e){console.error(e);res.status(500).json({error:"Не вдалося створити платіж. Спробуй пізніше."});}
});
app.get("/api/admin/summary",requireAuth,(req,res)=>{
 if(!adminEmail || req.user.email!==adminEmail)return res.status(403).json({error:"Немає доступу."});
 const users=db.prepare("SELECT COUNT(*) n FROM users").get().n;
 const paid=db.prepare("SELECT COUNT(*) n FROM users WHERE paid=1").get().n;
 const payments=db.prepare("SELECT COUNT(*) n,COALESCE(SUM(amount_total),0) total FROM payments WHERE status='paid'").get();
 res.json({users,paid,payments});
});
app.use(express.static(path.join(__dirname,"public")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(port,()=>console.log(`English50 is running at ${appUrl}`));
